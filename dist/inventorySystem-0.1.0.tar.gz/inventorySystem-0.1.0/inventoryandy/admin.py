from django.contrib import admin
from .models import Inventoryandy


admin.site.register(Inventoryandy)